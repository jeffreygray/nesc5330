function sequencePredict
clear all;
more off;
t1 = cputime;
tic %start chronometer

%%%%%
% code by Blake Thomas, April 18, 2012
% Kai Chang, William Levy
%%%%%

% Seed the RNG. This may be too fancy
seed = 1; 
rng(seed);

% All matricies are in format row = neuron, col = time

ni          	= 1000;  % num neurons
Activity 		= 0.1;  % desired network activity level
Con 			= 0.1;  % neuron interconnectivity
wStart      	= 0.4;  % all weights start at 0.4
wDist       	= 0;
mu          	= 0.005;  % synaptic modifcation rate constant
K0          	= .68;  % shunting rest conductance
epsilonK0   	= 0.5;  % rate constant for delta-K0
KFB 	    		= 0.047;  % feedback inhibition scaling constant
KFF 			= 0.014;  % feedforward inhibition scaling constant
lambdaFB 		= 0.1;  % feedback interneuron synaptic modification rate

NumToFire 	= Activity*ni;  % number of neurons firing on each timestep

synapmod 		= 1;  % 1: turn on synaptic modifcation
competitive 	= 0;  % 1: turn on competitive inhibition
saveWeights 	= 0;  % 1: save weights every trial THIS FILLS THE HARD-DRIVE
testing     	= 0;  % bool flag for testing

%%% Time Settings in ms/TIMESTEPS;
deltaT    	= 20;  % milliseconds (ms) should divide evenly into 20ms
lenStimulus  	= 60;  % length of each stimulus
stim			= lenStimulus/deltaT;
numPatterns	= 12;  %
numPatTest	= 3;  %
Me          	= 30;  % number of neurons used in each conditioning pattern
shift		= 10;  % overlap of each pattern
NumTrials 	= 50;  % number of times to run training trials
TrainTime 	= numPatterns * stim;  % sequence depth for training
TestTime  	= numPatterns * stim;  % sequence depth for testing

% create inputsequences
TrainSeq = zeros(ni, TrainTime);  % create sequence of zeros
TestSeq  = zeros(ni, TestTime);  % create sequence of zeros

for i = 1:numPatterns
   nstart = (i-1) * shift + 1;
   nstop  = nstart + Me - 1;
   tstart = (i-1) * stim + 1;
   tstop  = tstart + stim - 1;
   TrainSeq(nstart:nstop, tstart:tstop) = 1;
   if (i <= numPatTest)
      TestSeq(nstart:nstop, tstart:tstop) = 1;
   end
end %for i

%NMDA Settings MUST BE ZERO, WILL NOT WORK OTHERWISE
lenrise   	= 0;  % NMDArise time in ms
rise      	= lenrise/deltaT;  % NMDArise
alphaFold 	= 80;  % e-fold decay time in ms
alpha     	= exp(-deltaT/alphaFold);  % exp(-deltaT / 100ms) for 100ms e-fold decay

SequenceDepth = TrainTime;

pathstring = './results/';
mkdir(pathstring);

save([pathstring,'TrainSeq.mat'], 'TrainSeq')
save([pathstring,'TestSeq.mat'], 'TestSeq')

% create surface and act/k0 trackers
Totalsurface = zeros(NumTrials,TrainTime);
k0tracker    = zeros(NumTrials,1);
ActTracker   = zeros(NumTrials,1);

% load or create weight and connection matricies
[FanInCon, cInMatrix, wInMatrix] = CreateNetwork(ni, Con, wStart, wDist);

fbWeightList = ones(1,ni);

%disp('Begin Training');
for counttrials = 1:(NumTrials+1) %counttrials = 1;

    Inputs = TrainSeq;

  if(1)
   disp(['Trial: ',num2str(counttrials)]);
   toc
  end
  
  if (counttrials > NumTrials) % if last run test instead of train
	Inputs = TestSeq;
	SequenceDepth = TestTime;
	synapmod = 0;  %no synaptic modification during testing
	testing = 1;
  end
  
  tcount = 1; % counter tracks time

  % load or create static Z0
  Z0 = zeros(1,ni);
  Z0 = CreateZ0(ni, Activity, shift*numPatterns + Me);
  Z0fired = Z0(1:(ni*Activity),2);
  Z0 = spconvert(Z0);
  for t = 1:ni
     if( Z0(t) == 2) 
        Z0(t)=1;
     end
  end

  Z = zeros(ni, SequenceDepth); %clear Z, the firing pattern matrix
  Zbar = zeros(ni,1); %now we are NOT storing all Zbars
  prevZbar = zeros(ni,1); %now we are storing the Zbar of synapse i when it gets activated the next time.
  timeSinceFired = ones(ni,1)*(TrainTime+1); 
  firstAct       = zeros(ni,1) - (2 * rise); %this will be used if a neuron fires twice during a rise (rise must be > 2 in this case)
  riseUntil      = zeros(ni,1); %needed for zBar
  timeSinceFired(Z0fired) = 0;  %the Z0's fired.
  excitation = zeros(ni, 1); 
  % Calculate excitation

  if(competitive == 1)
    for i = 1:ni        
         excitation(i) = CalcExcitation(wInMatrix(i, 1:FanInCon(i)), cInMatrix(i, 1:FanInCon(i))+1, Z0', 2);
    end
    % Competitively select which neurons fire
    Z(:,1) =  CompetitiveInhibition( excitation, Z(:,1), ni, NumToFire);
  else 
    for i = 1:ni
	 excitation(i) = CalcExcitationWithInhibition(wInMatrix(i, 1:FanInCon(i)), cInMatrix(i, 1:FanInCon(i))+1, Inputs(:,1), fbWeightList, Z0', ni, 2, K0, KFB, KFF);
    end%for ni
	% Network is free-running, so all neurons which reach threshold may fire  
	Z(:,1) = (excitation >= 0.5) | Inputs(i,1);
	timeSinceFired = (timeSinceFired + 1) .* (1 - Z(:,1));

  end %if competitive

  fbWeightList = DavesRule(Z0, sum(Z(:,tcount)), fbWeightList, lambdaFB, Activity, ni);
  fbWeightList = fbWeightList - fbWeightList .* (fbWeightList < 0); %catch below zeros

% Perform synaptic modification if desired
  if (synapmod == 1)
	Zbar = Z0'; %else Zbar is all zeros.
	for post = 1:ni
	  if(Z(post,1)) wInMatrix(post,1:FanInCon(post)) = UpdateWeights( Z(post,tcount), Zbar(cInMatrix(post,1:FanInCon(post))+1)', wInMatrix(post,1:FanInCon(post)), mu); end;
	end
  end
  
  % Perform similar calculations for all future timesteps, but using Z(t-1)
  % instead of Z0
  for k = 2:SequenceDepth
     tcount = tcount+1; 	%time advances to the present
     
     if (synapmod == 1) %has to be done now because Zbar depends on when i fires!    
	%timeSinceFired
	Zbar = CalculateZbar( Z, prevZbar, tcount-1, alpha, ni, 0, timeSinceFired);  
     end

     Z(:, tcount) = Inputs(:,k);	%external inputs are introduced
	if(competitive == 1)
        %loop to do weighted summation to find excitation
        	for i = 1:ni             
        	    excitation(i) = CalcExcitation(wInMatrix(i, 1:FanInCon(i)), cInMatrix(i, 1:FanInCon(i))+1, Z, tcount);
        	end
        % Handle competitive inhibition 
      		Z(:,tcount) =  CompetitiveInhibition(excitation, Z(:,tcount), ni, NumToFire); 
     	else
	   for i = 1:ni  
             excitation(i) = CalcExcitationWithInhibition(wInMatrix(i, 1:FanInCon(i)), cInMatrix(i, 1:FanInCon(i))+1, Inputs(:,k), fbWeightList, Z, ni, tcount, K0, KFB, KFF); 
           end
    	   Z(:,tcount) = (excitation >= 0.5) | Inputs(:,tcount); 
	   timeSinceFired = (timeSinceFired + 1) .* (1 - Z(:,tcount));
	
	end

	%Dave's Rule
	fbWeightList = DavesRule(Z(:,tcount-1)', sum(Z(:,tcount)), fbWeightList, lambdaFB, Activity, ni) ;
	fbWeightList = fbWeightList - fbWeightList .* (fbWeightList < 0); %catch below zeros

	% Perform synaptic modification if desired
	if (synapmod == 1)   
	  for post = 1:ni
		if (0 == timeSinceFired(post))
		    wInMatrix(post,1:FanInCon(post)) = UpdateWeights( Z(post,tcount), Zbar(cInMatrix(post,1:FanInCon(post))+1), wInMatrix(post,1:FanInCon(post)), mu);
		end%if
	  end%for
	end%if
  end

  %Store both surfaces
	Totalsurface(counttrials,:) = sum(Z)/ni;	%activity for entire network

  %Save firing matrix Z
  if counttrials > NumTrials
	save([pathstring,'/testing_' ,num2str(counttrials),'.mat'], 'Z')
  else
	save([pathstring,'/training_',num2str(counttrials),'.mat'], 'Z')
  end

  %Save Weights Every Trial
  if (saveWeights == 1)
     save(['weights_iteration',num2str(counttrials),'.mat'],'wInMatrix')
  end

  %Store K0, Activity
  k0tracker(counttrials) = K0;
  trialactivity = sum(sum(Z))/(ni*TrainTime);
  ActTracker(counttrials)= trialactivity;

  %Modify K0
  deltaK0    = epsilonK0 * (trialactivity - Activity);
  K0         = K0 + deltaK0;

end% for trials

%Save the created surfaces/histories
save([pathstring, '/surface.mat'     ],'Totalsurface')
save([pathstring, '/K0history.mat'   ],'k0tracker')	
save([pathstring, '/Acthistory.mat'  ],'ActTracker')
save([pathstring, '/finalweights.mat'],'wInMatrix')

disp('TraceConditioning Complete.');
toc %show elapsed time
t2 = cputime;
disp(['cpu cycles elapsed: ', num2str(t2-t1)]);
