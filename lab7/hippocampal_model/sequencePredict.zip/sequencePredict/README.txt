README.txt

seqeuncePredict.m is a CA-3 hippocampus simulator used to simulate sequence learning.
The network is repeatedly presented with a sequence which it then tries to replicate during a testing trial.
This function saves the firing of each training trial, K0 at the end of each trial, average activity of each trial, a surface that has the activity of each time-step of each trial, and the weights at the end of training. These can all be visualized with displaySeqResults.m

CreateNetwork.m creates the sparse network. It returns three matrices. 
FanInCon is an ni by 1 vector. Each value is how many inputs neuron n has.
cInMatrix is an ni by (ni * connectivity) matrix. Each row n is a list of neurons that project to neuron n.
wInMatrix is an ni by (ni * connectivity) matrix. Each row n is a list of weights of the corresponding connection from cInMatrix. That is, if the 5th element of the 21st row of cInMatrix is 14, and the 5th element of the 21st row of wInMatrix is 0.35, then there is a synapse from neuron 14 onto neuron 21 with weight 0.35.

CreateZ0.m generates a random firing pattern for the 'zeroeth' time-step so that the network starts with some activity on the first time-step.
It avoids firing any of the neurons involved in the pattern. It returns a sparse matrix Z0, where the second column is the neurons that are fired.

CalcExcitation.m calculates the excitation of a neuron j according to the firing pattern of the last time-step Zi and the weights Wij: yj = Zi' * Wij;
It returns a scalar on [0, inf).

CompetitiveInhibition.m selects activity*ni number of neurons to fire by sorting them from highest excitation to lowest excitation. This method does not use Ks to calculate inhibition and this network is NOT free-running.

CalcExcitationWithInhibition.m calculates the excitation after inhibition of neuron j according to the formula: EwI = yj / (yj + K0 + KFB*sum(Zi * WiFB) + KFF*sum(Xi));
It returns a scalar on [0,1]. This number is compared with threshold to determine if the neuron fires.

DavesRule.m updates the synaptic weights from each neuron to the FB inhibition interneuron, WiFB (FBweightList). It uses the formula WiFB = WiFB + lambdaFB * Zi(t-1) * (Activity(t) - desiredAct). This is an error corrector.

CalculateZbar.m calculates Zbar for all neurons i. Zbar represents the current across the NMDA receptor. This peaks at 1, 20ms following an activated synapse, and then decays exponentially at the rate alpha. It returns a column vector Zbar with each value on [0,1].

UpdateWeights.m updates the neuron-to-neuron weights for a single neuron according to the rule: Wij = Wij + mu * Zj * (Zbarij - Wij);
It returns a row vector of each updated weight with the values on [0,1].
